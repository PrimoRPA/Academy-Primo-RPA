$stagingDirectory = "$(Build.SourcesDirectory)"
Get-ChildItem -Path $stagingDirectory -Recurse -Filter "*.bak" | Remove-Item -Force
