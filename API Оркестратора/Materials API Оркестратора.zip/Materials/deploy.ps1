# Предварительные настройки
[System.Net.ServicePointManager]::ServerCertificateValidationCallback = {$true}
Add-Type -AssemblyName "System.Net.Http"

# -------------------------------------------------------------------------------------
# Константы (получение происходит из окружения Azure)

$login = "$env:orchLogin"
$password = "$env:orchPassword"
$url = "$env:orchUrl"
$directory = "$(Build.ArtifactStagingDirectory)"
$filename = "$(Build.BuildId).zip"

# -------------------------------------------------------------------------------------
# Запрос на авторизацию

$headers = @{
    "TenantId" = ""
    "Content-Type" = "application/json"
}
$body = @"
{
  "userName": "$login",
  "password": "$password"
}
"@

$requestUrl = "$url/api/account"
Write-Host "Request URL auth: $requestUrl"
$response = Invoke-RestMethod -Uri $requestUrl -Method 'POST' -Headers $headers -Body $body -ErrorAction Stop

# Получение токена
$token = $response.token

# -------------------------------------------------------------------------------------
# Запрос GUID

$headers = @{
    "Authorization" = "Bearer $token"
}
$requestUrl = "$url/api/RpaProjects/ArchiveGuid"
$response = Invoke-RestMethod -Uri $requestUrl -Method 'GET' -Headers $headers

# Получение значения guid для архива
$guid = $response.Trim()

# -------------------------------------------------------------------------------------
# Отправка архива проекта

Add-Type -AssemblyName "System.Net.Http"

$headers = New-Object "System.Collections.Generic.Dictionary[[String],[String]]"
$headers.Add("Authorization", "Bearer $token")

$multipartContent = [System.Net.Http.MultipartFormDataContent]::new()
$multipartFile = "$directory\$filename"
$FileStream = [System.IO.FileStream]::new($multipartFile, [System.IO.FileMode]::Open)
$fileHeader = [System.Net.Http.Headers.ContentDispositionHeaderValue]::new("form-data")
$fileHeader.Name = "file1"
$fileHeader.FileName = "$filename"
$fileContent = [System.Net.Http.StreamContent]::new($FileStream)
$fileContent.Headers.ContentDisposition = $fileHeader
$fileContent.Headers.ContentType = [System.Net.Http.Headers.MediaTypeHeaderValue]::new("application/octet-stream")
$multipartContent.Add($fileContent)
$body = $multipartContent
$multipartContent.Headers | Format-List

$response = Invoke-RestMethod "$url/api/RpaProjects/archive/$guid" -Method 'POST' -Headers $headers -Body $body

# -------------------------------------------------------------------------------------
# Добавление версии проекта

$headers = @{
    "Content-Type" = "application/json"
    "Authorization" = "Bearer $token"
}

$body = @"
{
  "name": "TestPr",
  "description": "",
  "mainWorkflow": "Main.ltw",
  "softPlatform": "2",
  "runConfig": "0",
  "runConfigCustom": "",
  "mock": true,
  "durationLevel": "0",
  "robotDistrVersions": "",
  "closeRDPSession": true,
  "exclusiveLaunch": true,
  "limitedLaunch": 0,
  "noDuplicateDeferredQueue": true,
  "sessionsReleaseDelay": 0,
  "exclusiveSessionsRelease": true,
  "fileId": "$guid"
}
"@

$requestUrl = "$url/api/RpaProjects/v2?parentid=14"
$response = Invoke-RestMethod -Uri $requestUrl -Method 'POST' -Headers $headers -Body $body
